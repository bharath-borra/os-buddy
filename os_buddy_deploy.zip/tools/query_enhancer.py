def enhance_query(original_query):
    """
    Enhance the query using NER or LLM expansion.
    """
    # Simple pass-through for now
    return original_query
